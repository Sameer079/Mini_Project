/** 
* @file calculator_operations.h
* Calculator application with 4 mathematical operations
*
*/
#include<stdio.h>
#include<conio.h>
#include<stdlib.h>
#include <windows.h>
int check_draw(int turn);